'''Example Lambda package file'''


def lambda_handler(event, context):
    '''Example lambda function'''
    return 'Hello from Cloudify & Lambda'
